package com.practise.kafkaproducerconsumerapplication.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumer {
    @KafkaListener(topics = {"fruits"},groupId = "testJava")
    public void consumeMessage(String message) {
        System.out.println(message);
    }
}
