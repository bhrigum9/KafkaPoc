package com.practise.kafkaproducerconsumerapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaproducerconsumerapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
